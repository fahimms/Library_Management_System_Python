from tkinter import *
from tkinter import ttk
from time import strftime
import mysql.connector as mysql
from tkinter import messagebox
import datetime
from PIL import ImageTk, Image


screen = Tk()
screen.title("DIU Library Management System")
screen.geometry("1500x800+0+0")
screen.resizable(False, False)
screen.iconbitmap('diu.ico')



#--(Add BTN)Function for add data
def add_data():
    if(member_db.get()=='' or prn_db.get()=='' or id_db.get()=='' or firstname_db.get()=='' or lastname_db.get()=='' or address1_db.get()=='' or address2_db.get()=='' or postcode_db.get()=='' or mobile_db.get()=='' or bookid_db.get()=='' or booktitle_db.get()=='' or auther_db.get()=='' or dateborrowed_db.get()=='' or datedue_db.get()=='' or daysonbook_db.get()=='' or lateratefine_db.get()=='' or dateoverdue_db.get()=='' or  finalprice_db.get()==''):
        messagebox.showinfo("Insert Status", "All Fields are required")

    else:
        con = mysql.connect(host="localhost", user="root", password="", database="diu_library_management_system")
        cursor = con.cursor()
        cursor.execute("insert into library values('" + member_db.get() + "','" + prn_db.get() + "','" + id_db.get() + "','" + firstname_db.get() + "','" + lastname_db.get() + "','" + address1_db.get() + "','" + address2_db.get() + "','" + postcode_db.get() + "','" + mobile_db.get() + "','" + bookid_db.get() + "','" + booktitle_db.get() + "','" + auther_db.get() + "','" + dateborrowed_db.get() + "','" + datedue_db.get() + "','" + daysonbook_db.get() + "','" + lateratefine_db.get() + "','" + dateoverdue_db.get() + "','" + finalprice_db.get() + "')")

        cursor.execute("commit")
        messagebox.showinfo("Insert Status", "Data Has Been Inserted Successfully")
        fatch_data()#For Updating Showing Database
        con.close()




#----(Update BTN)Funtion for data update
def update_btn():
    if (
        member_db.get() == '' or prn_db.get() == '' or id_db.get() == '' or firstname_db.get() == '' or lastname_db.get() == '' or address1_db.get() == '' or address2_db.get() == '' or postcode_db.get() == '' or mobile_db.get() == '' or bookid_db.get() == '' or booktitle_db.get() == '' or auther_db.get() == '' or dateborrowed_db.get() == '' or datedue_db.get() == '' or daysonbook_db.get() == '' or lateratefine_db.get() == '' or dateoverdue_db.get() == '' or finalprice_db.get() == ''):
        messagebox.showinfo("Update Status", "All Fields are required")

    else:
        con = mysql.connect(host="localhost", user="root", password="", database="diu_library_management_system")
        cursor = con.cursor()
        cursor.execute("update library set Member='" + member_db.get() + "', ID='" + id_db.get() + "', FirstName='" + firstname_db.get() + "', LastName='" + lastname_db.get() + "', Address1='" + address1_db.get() + "', Address2='" + address2_db.get() + "', PostID='" + postcode_db.get() + "', Mobile='" + mobile_db.get() + "', BookID='" + bookid_db.get() + "', BookTitle='" + booktitle_db.get() + "', Auther='" + auther_db.get() + "', DateBorrowed='" + dateborrowed_db.get() + "', DateDue='" + datedue_db.get() + "', DaysOnBook='" + daysonbook_db.get() + "', LateReturnFine='" + lateratefine_db.get() + "', DateOverDue='" + dateoverdue_db.get() + "', FinalPrice='" + finalprice_db.get() + "' where PRN_NO='"+prn_db.get()+"'")

        cursor.execute("commit")
        messagebox.showinfo("Update Status", "Data Has Been Updated Successfully")
        fatch_data()  # For Updating Showing Database
        con.close()



#----(Show BTN) Showing data in right TextBox
def showing_data_in_textbox():
    txtBox.delete("1.0", END)  # clear info showing text box

    txtBox.insert(END, "Member Type:\t\t" + member_db.get() + "\n")
    txtBox.insert(END, "PRN No. :\t\t" + prn_db.get() + "\n")
    txtBox.insert(END, "ID No. :\t\t" + id_db.get() + "\n")
    txtBox.insert(END, "First Name:\t\t" + firstname_db.get() + "\n")
    txtBox.insert(END, "Surname:\t\t" + lastname_db.get() + "\n")
    txtBox.insert(END, "Address1:\t\t" + address1_db.get() + "\n")
    txtBox.insert(END, "Address2:\t\t" + address2_db.get() + "\n")
    txtBox.insert(END, "Post Code:\t\t" + postcode_db.get() + "\n")
    txtBox.insert(END, "Mobile No. :\t\t" + mobile_db.get() + "\n")
    txtBox.insert(END, "Book ID:\t\t" + bookid_db.get() + "\n")
    txtBox.insert(END, "Book Title:\t\t" + booktitle_db.get() + "\n")
    txtBox.insert(END, "Auther:\t\t" + auther_db.get() + "\n")
    txtBox.insert(END, "DateBorrowed:\t\t" + dateborrowed_db.get() + "\n")
    txtBox.insert(END, "Date Due:\t\t" + datedue_db.get() + "\n")
    txtBox.insert(END, "DaysOnBook:\t\t" + daysonbook_db.get() + "\n")
    txtBox.insert(END, "LateRateFine:\t\t" + lateratefine_db.get() + "\n")
    txtBox.insert(END, "DateOverDue:\t\t" + dateoverdue_db.get() + "\n")
    txtBox.insert(END, "Final Price:\t\t" + finalprice_db.get() + "\n")



#----(Delete BTN)Function for delete
def delete():
    if (prn_db.get()=="" or id_db.get()==""):
        messagebox.showinfo("Error", "First Select The Member!")
    else:
        con = mysql.connect(host="localhost", user="root", password="", database="diu_library_management_system")
        cursor = con.cursor()
        cursor.execute("delete from library where PRN_NO='"+prn_db.get()+"' and ID='"+id_db.get()+"'")

        cursor.execute("commit")
        messagebox.showinfo("Delete Status", "Data Has Been Deleted Successfully")
        fatch_data()  # For Updating Showing Database
        con.close()



#----(Reset BTN)Function For Reset Button
def reset():
    member_db.set('')
    prn_db.set('')
    id_db.set('')
    firstname_db.set('')
    lastname_db.set('')
    address1_db.set('')
    address2_db.set('')
    postcode_db.set('')
    mobile_db.set('')
    bookid_db.set('')
    booktitle_db.set('')
    auther_db.set('')
    dateborrowed_db.set('')
    datedue_db.set('')
    daysonbook_db.set('')
    lateratefine_db.set('')
    dateoverdue_db.set('')
    finalprice_db.set('')
    txtBox.delete("1.0",END)#clear info showing text box





#----Function Button For Exit Button
def exit_btn():
    exit_btn=messagebox.askyesno("DIU Library Management System","Do you want to exit?")

    if exit_btn>0:
        screen.destroy()
    else:
        return




#--------Function for press on book name to automated fill the boxes
def selectBook(event=""):
    value=listBox.curselection()[0]
    x=listBox.get(value)

    if(x=="C Programming Absolute Beginners Guide"):
        bookid_db.set("C001")
        booktitle_db.set("C Programming")
        auther_db.set("Mikel Jack")

        d = datetime.date.today()
        dd = datetime.timedelta(days=15)
        ddd = d + dd

        dateborrowed_db.set(str(d))
        dateoverdue_db.set(str(ddd))
        daysonbook_db.set(str(15))
        lateratefine_db.set("40 TK")
        datedue_db.set("NO")
        finalprice_db.set("830 TK")

    elif (x == "The C Programming Language"):
        bookid_db.set("C002")
        booktitle_db.set("C Programming")
        auther_db.set("Mikel Jack")

        d = datetime.date.today()
        dd = datetime.timedelta(days=15)
        ddd = d + dd

        dateborrowed_db.set(str(d))
        dateoverdue_db.set(str(ddd))
        daysonbook_db.set(str(15))
        lateratefine_db.set("40 TK")
        datedue_db.set("NO")
        finalprice_db.set("450 TK")

    elif (x == "Learn C the Hard Way"):
        bookid_db.set("C003")
        booktitle_db.set("C Programming")
        auther_db.set("Mikel Jack")

        d = datetime.date.today()
        dd = datetime.timedelta(days=15)
        ddd = d + dd

        dateborrowed_db.set(str(d))
        dateoverdue_db.set(str(ddd))
        daysonbook_db.set(str(15))
        lateratefine_db.set("40 TK")
        datedue_db.set("NO")
        finalprice_db.set("729 TK")

    elif (x == "C++ Primer"):
        bookid_db.set("CC001")
        booktitle_db.set("C++ Programming")
        auther_db.set("AR. Rahaman")

        d = datetime.date.today()
        dd = datetime.timedelta(days=15)
        ddd = d + dd

        dateborrowed_db.set(str(d))
        dateoverdue_db.set(str(ddd))
        daysonbook_db.set(str(15))
        lateratefine_db.set("40 TK")
        datedue_db.set("NO")
        finalprice_db.set("1129 TK")

    elif (x == "Effective Modern C++"):
        bookid_db.set("CC002")
        booktitle_db.set("C++ Programming")
        auther_db.set("AR. Rahaman")

        d = datetime.date.today()
        dd = datetime.timedelta(days=15)
        ddd = d + dd

        dateborrowed_db.set(str(d))
        dateoverdue_db.set(str(ddd))
        daysonbook_db.set(str(15))
        lateratefine_db.set("40 TK")
        datedue_db.set("NO")
        finalprice_db.set("625 TK")

    elif (x == "The C++ Programming Language"):
        bookid_db.set("CC003")
        booktitle_db.set("C++ Programming")
        auther_db.set("AR. Rahaman")

        d = datetime.date.today()
        dd = datetime.timedelta(days=15)
        ddd = d + dd

        dateborrowed_db.set(str(d))
        dateoverdue_db.set(str(ddd))
        daysonbook_db.set(str(15))
        lateratefine_db.set("40 TK")
        datedue_db.set("NO")
        finalprice_db.set("975 TK")

    elif (x == "Python Crash Course"):
        bookid_db.set("P001")
        booktitle_db.set("Python Programming")
        auther_db.set("Salman Khan")

        d = datetime.date.today()
        dd = datetime.timedelta(days=15)
        ddd = d + dd

        dateborrowed_db.set(str(d))
        dateoverdue_db.set(str(ddd))
        daysonbook_db.set(str(15))
        lateratefine_db.set("40 TK")
        datedue_db.set("NO")
        finalprice_db.set("255 TK")

    elif (x == "Automate the Boring Stuff With Python"):
        bookid_db.set("P002")
        booktitle_db.set("Python Programming")
        auther_db.set("Salman Khan")

        d = datetime.date.today()
        dd = datetime.timedelta(days=15)
        ddd = d + dd

        dateborrowed_db.set(str(d))
        dateoverdue_db.set(str(ddd))
        daysonbook_db.set(str(15))
        lateratefine_db.set("40 TK")
        datedue_db.set("NO")
        finalprice_db.set("685 TK")

    elif (x == "Learning Python"):
        bookid_db.set("P003")
        booktitle_db.set("Python Programming")
        auther_db.set("Salman Khan")

        d = datetime.date.today()
        dd = datetime.timedelta(days=15)
        ddd = d + dd

        dateborrowed_db.set(str(d))
        dateoverdue_db.set(str(ddd))
        daysonbook_db.set(str(15))
        lateratefine_db.set("40 TK")
        datedue_db.set("NO")
        finalprice_db.set("605 TK")

    elif (x == "The Hundred-Page Machine Learning Book"):
        bookid_db.set("M001")
        booktitle_db.set("Machine Learning")
        auther_db.set("Masrafi Bin Mortaza")

        d = datetime.date.today()
        dd = datetime.timedelta(days=15)
        ddd = d + dd

        dateborrowed_db.set(str(d))
        dateoverdue_db.set(str(ddd))
        daysonbook_db.set(str(15))
        lateratefine_db.set("40 TK")
        datedue_db.set("NO")
        finalprice_db.set("600 TK")

    elif (x == "Machine Learning For Hackers"):
        bookid_db.set("M002")
        booktitle_db.set("Machine Learning")
        auther_db.set("Masrafi Bin Mortaza")

        d = datetime.date.today()
        dd = datetime.timedelta(days=15)
        ddd = d + dd

        dateborrowed_db.set(str(d))
        dateoverdue_db.set(str(ddd))
        daysonbook_db.set(str(15))
        lateratefine_db.set("40 TK")
        datedue_db.set("NO")
        finalprice_db.set("350 TK")

    elif (x == "Machine Learning"):
        bookid_db.set("M003")
        booktitle_db.set("Machine Learning")
        auther_db.set("Masrafi Bin Mortaza")

        d = datetime.date.today()
        dd = datetime.timedelta(days=15)
        ddd = d + dd

        dateborrowed_db.set(str(d))
        dateoverdue_db.set(str(ddd))
        daysonbook_db.set(str(15))
        lateratefine_db.set("40 TK")
        datedue_db.set("NO")
        finalprice_db.set("1150 TK")

    elif (x == "Head First Statistics"):
        bookid_db.set("DS001")
        booktitle_db.set("Data Science")
        auther_db.set("Sakib Al Hassan")

        d = datetime.date.today()
        dd = datetime.timedelta(days=15)
        ddd = d + dd

        dateborrowed_db.set(str(d))
        dateoverdue_db.set(str(ddd))
        daysonbook_db.set(str(15))
        lateratefine_db.set("40 TK")
        datedue_db.set("NO")
        finalprice_db.set("1340 TK")

    elif (x == "Practical Statistics For Data Scientists"):
        bookid_db.set("DS002")
        booktitle_db.set("Data Science")
        auther_db.set("Sakib Al Hassan")

        d = datetime.date.today()
        dd = datetime.timedelta(days=15)
        ddd = d + dd

        dateborrowed_db.set(str(d))
        dateoverdue_db.set(str(ddd))
        daysonbook_db.set(str(15))
        lateratefine_db.set("40 TK")
        datedue_db.set("NO")
        finalprice_db.set("958 TK")

    elif (x == "Introduction to Probability"):
        bookid_db.set("DS003")
        booktitle_db.set("Data Science")
        auther_db.set("Sakib Al Hassan")

        d = datetime.date.today()
        dd = datetime.timedelta(days=15)
        ddd = d + dd

        dateborrowed_db.set(str(d))
        dateoverdue_db.set(str(ddd))
        daysonbook_db.set(str(15))
        lateratefine_db.set("40 TK")
        datedue_db.set("NO")
        finalprice_db.set("1452 TK")

    elif (x == "The Man Who Counted"):
        bookid_db.set("MT001")
        booktitle_db.set("Math")
        auther_db.set("MS. Dhoni")

        d = datetime.date.today()
        dd = datetime.timedelta(days=15)
        ddd = d + dd

        dateborrowed_db.set(str(d))
        dateoverdue_db.set(str(ddd))
        daysonbook_db.set(str(15))
        lateratefine_db.set("40 TK")
        datedue_db.set("NO")
        finalprice_db.set("1652 TK")

    elif (x == "The Triumph of Numbers"):
        bookid_db.set("MT002")
        booktitle_db.set("Math")
        auther_db.set("MS. Dhoni")

        d = datetime.date.today()
        dd = datetime.timedelta(days=15)
        ddd = d + dd

        dateborrowed_db.set(str(d))
        dateoverdue_db.set(str(ddd))
        daysonbook_db.set(str(15))
        lateratefine_db.set("40 TK")
        datedue_db.set("NO")
        finalprice_db.set("489 TK")

    elif (x == "Zero"):
        bookid_db.set("MT003")
        booktitle_db.set("Math")
        auther_db.set("MS. Dhoni")

        d = datetime.date.today()
        dd = datetime.timedelta(days=15)
        ddd = d + dd

        dateborrowed_db.set(str(d))
        dateoverdue_db.set(str(ddd))
        daysonbook_db.set(str(15))
        lateratefine_db.set("40 TK")
        datedue_db.set("NO")
        finalprice_db.set("564 TK")

    elif (x == "Probabilistic Robotics"):
        bookid_db.set("RB001")
        booktitle_db.set("Robotic")
        auther_db.set("MS. Dhoni")

        d = datetime.date.today()
        dd = datetime.timedelta(days=15)
        ddd = d + dd

        dateborrowed_db.set(str(d))
        dateoverdue_db.set(str(ddd))
        daysonbook_db.set(str(15))
        lateratefine_db.set("40 TK")
        datedue_db.set("NO")
        finalprice_db.set("652 TK")

    elif (x == "Robotics Modelling, Planning and Control"):
        bookid_db.set("RB002")
        booktitle_db.set("Robotic")
        auther_db.set("MS. Dhoni")

        d = datetime.date.today()
        dd = datetime.timedelta(days=15)
        ddd = d + dd

        dateborrowed_db.set(str(d))
        dateoverdue_db.set(str(ddd))
        daysonbook_db.set(str(15))
        lateratefine_db.set("40 TK")
        datedue_db.set("NO")
        finalprice_db.set("358 TK")

    elif (x == "Planning Algorithms"):
        bookid_db.set("RB003")
        booktitle_db.set("Robotic")
        auther_db.set("MS. Dhoni")

        d = datetime.date.today()
        dd = datetime.timedelta(days=15)
        ddd = d + dd

        dateborrowed_db.set(str(d))
        dateoverdue_db.set(str(ddd))
        daysonbook_db.set(str(15))
        lateratefine_db.set("40 TK")
        datedue_db.set("NO")
        finalprice_db.set("325 TK")


#----Functing for showing database
def fatch_data():
    con = mysql.connect(host="localhost", user="root", password="", database="diu_library_management_system")
    cursor = con.cursor()
    cursor.execute("select * from library")
    rows=cursor.fetchall()

    if len(rows)!=0:
        library_table.delete(*library_table.get_children())
        for i in rows:
            library_table.insert("",END,values=i)

        cursor.execute("commit")
    con.close()






#--------Function for press on member to automated fill the boxes
def get_member_info(event=""):
    cursor_row=library_table.focus()
    content= library_table.item(cursor_row)
    row=content['values']

    member_db.set(row[0])
    prn_db.set(row[1])
    id_db.set(row[2])
    firstname_db.set(row[3])
    lastname_db.set(row[4])
    address1_db.set(row[5])
    address2_db.set(row[6])
    postcode_db.set(row[7])
    mobile_db.set(row[8])
    bookid_db.set(row[9])
    booktitle_db.set(row[10])
    auther_db.set(row[11])
    dateborrowed_db.set(row[12])
    datedue_db.set(row[13])
    daysonbook_db.set(row[14])
    lateratefine_db.set(row[15])
    dateoverdue_db.set(row[16])
    finalprice_db.set(row[17])



#----(Clock)Function for clock
def clock():
    a = strftime('%H:%M:%S %p')
    clock_lable.config(text=a)
    clock_lable.after(1000, clock)



# --Variable
member_db = StringVar()
prn_db = StringVar()
id_db = StringVar()
firstname_db = StringVar()
lastname_db = StringVar()
address1_db = StringVar()
address2_db = StringVar()
postcode_db = StringVar()
mobile_db = StringVar()
bookid_db = StringVar()
booktitle_db = StringVar()
auther_db = StringVar()
dateborrowed_db = StringVar()
datedue_db = StringVar()
daysonbook_db = StringVar()
lateratefine_db = StringVar()
dateoverdue_db = StringVar()
finalprice_db = StringVar()

#==========Main Work=========
# --Banner Picture
banner = Image.open("banner.png")
banner_resized = banner.resize((1486, 120), Image.ANTIALIAS)
banner_pic = ImageTk.PhotoImage(banner_resized)
banner = ImageTk.PhotoImage(file="banner.png")
banner_label = Label(screen, image=banner_pic, relief=RIDGE, bd=7)
banner_label.place(x=0, y=0)

clock_lable=Label(screen,font=("ds-digital",20),bd=5,relief=RIDGE, bg="black",foreground="cyan")
clock_lable.place(x=1300,y=50)
clock()



# --Info Backend Frame
frame = Frame(screen, bd=10, relief=RIDGE, padx=13, bg="powder blue")
frame.place(x=0, y=130, width=1500, height=400)

# ----Font Left Info Frame
membership_info = LabelFrame(frame, padx=20, pady=5, text="Library Membership Information", bg="powder blue",
                                     fg='blue',
                                     bd=8, font=("times new roman", 14, "bold"))
membership_info.place(x=0, y=0, width=860, height=365)

# ----Member Form
member_type_label = Label(membership_info, bg="powder blue", text="Member Type:", font=("arial", 12, "bold"),
                                  padx=6,
                                  pady=6)
member_type_label.grid(row=0, column=0, sticky=W)
member_type_combo_box = ttk.Combobox(membership_info, font=("arial", 12, "bold"), textvariable=member_db, width=27)
member_type_combo_box["value"] = ("Student", "Lecture", "Varsity Staff")
member_type_combo_box.grid(row=0, column=1)

prn_label = Label(membership_info, bg="powder blue", text="PRN No.", font=("arial", 12, "bold"), padx=6, pady=6)
prn_label.grid(row=1, column=0, sticky=W)
prn_txt = Entry(membership_info, font=("arial", 12, "bold"), textvariable=prn_db, width=29)
prn_txt.grid(row=1, column=1)

id_label = Label(membership_info, bg="powder blue", text="ID No.", font=("arial", 12, "bold"), padx=6, pady=6)
id_label.grid(row=2, column=0, sticky=W)
id_txt = Entry(membership_info, font=("arial", 12, "bold"), textvariable=id_db, width=29)
id_txt.grid(row=2, column=1)

first_name_label = Label(membership_info, bg="powder blue", text="First Name:", font=("arial", 12, "bold"),
                                 padx=6,
                                 pady=6)
first_name_label.grid(row=3, column=0, sticky=W)
first_name_txt = Entry(membership_info, font=("arial", 12, "bold"), textvariable=firstname_db, width=29)
first_name_txt.grid(row=3, column=1)

last_name_label = Label(membership_info, bg="powder blue", text="Surname:", font=("arial", 12, "bold"), padx=6,
                                pady=6)
last_name_label.grid(row=4, column=0, sticky=W)
last_name_txt = Entry(membership_info, font=("arial", 12, "bold"), textvariable=lastname_db, width=29)
last_name_txt.grid(row=4, column=1)

address1_label = Label(membership_info, bg="powder blue", text="Address1:", font=("arial", 12, "bold"), padx=6,
                               pady=6)
address1_label.grid(row=5, column=0, sticky=W)
address1_txt = Entry(membership_info, font=("arial", 12, "bold"), textvariable=address1_db, width=29)
address1_txt.grid(row=5, column=1)

address2_label = Label(membership_info, bg="powder blue", text="Address2:", font=("arial", 12, "bold"), padx=6,
                               pady=6)
address2_label.grid(row=6, column=0, sticky=W)
address2_txt = Entry(membership_info, font=("arial", 12, "bold"), textvariable=address2_db, width=29)
address2_txt.grid(row=6, column=1)

postCode_label = Label(membership_info, bg="powder blue", text="Post Code:", font=("arial", 12, "bold"), padx=6,
                               pady=6)
postCode_label.grid(row=7, column=0, sticky=W)
postCode_txt = Entry(membership_info, font=("arial", 12, "bold"), textvariable=postcode_db, width=29)
postCode_txt.grid(row=7, column=1)

mobile_label = Label(membership_info, bg="powder blue", text="Mobile:", font=("arial", 12, "bold"), padx=6,
                             pady=6)
mobile_label.grid(row=8, column=0, sticky=W)
mobile_txt = Entry(membership_info, font=("arial", 12, "bold"), textvariable=mobile_db, width=29)
mobile_txt.grid(row=8, column=1)

bookID_label = Label(membership_info, bg="powder blue", text="Book ID:", font=("arial", 12, "bold"), padx=6,
                             pady=6)
bookID_label.grid(row=0, column=2, sticky=W)
bookID_txt = Entry(membership_info, font=("arial", 12, "bold"), textvariable=bookid_db, width=29)
bookID_txt.grid(row=0, column=3)

bookTitle_label = Label(membership_info, bg="powder blue", text="Book Title:", font=("arial", 12, "bold"),
                                padx=6,
                                pady=6)
bookTitle_label.grid(row=1, column=2, sticky=W)
bookTitle_txt = Entry(membership_info, font=("arial", 12, "bold"), textvariable=booktitle_db, width=29)
bookTitle_txt.grid(row=1, column=3)

author_label = Label(membership_info, bg="powder blue", text="Author Name:", font=("arial", 12, "bold"), padx=6,
                             pady=6)
author_label.grid(row=2, column=2, sticky=W)
author_txt = Entry(membership_info, font=("arial", 12, "bold"), textvariable=auther_db, width=29)
author_txt.grid(row=2, column=3)

dateBorrowed_label = Label(membership_info, bg="powder blue", text="Date Borrowed:", font=("arial", 12, "bold"),
                                   padx=6,
                                   pady=6)
dateBorrowed_label.grid(row=3, column=2, sticky=W)
dateBorrowed_txt = Entry(membership_info, font=("arial", 12, "bold"), textvariable=dateborrowed_db, width=29)
dateBorrowed_txt.grid(row=3, column=3)

dateDue_label = Label(membership_info, bg="powder blue", text="Date Due:", font=("arial", 12, "bold"), padx=6,
                              pady=6)
dateDue_label.grid(row=4, column=2, sticky=W)
dateDue_txt = Entry(membership_info, font=("arial", 12, "bold"), textvariable=datedue_db, width=29)
dateDue_txt.grid(row=4, column=3)

daysOnBook_label = Label(membership_info, bg="powder blue", text="Days On Book:", font=("arial", 12, "bold"),
                                 padx=6,
                                 pady=6)
daysOnBook_label.grid(row=5, column=2, sticky=W)
daysOnBook_txt = Entry(membership_info, font=("arial", 12, "bold"), textvariable=daysonbook_db, width=29)
daysOnBook_txt.grid(row=5, column=3)

lateReturnFine_label = Label(membership_info, bg="powder blue", text="Late Return Fine:",
                                     font=("arial", 12, "bold"),
                                     padx=6, pady=6)
lateReturnFine_label.grid(row=6, column=2, sticky=W)
lateReturnFine_txt = Entry(membership_info, font=("arial", 12, "bold"), textvariable=lateratefine_db, width=29)
lateReturnFine_txt.grid(row=6, column=3)

dateOverDue_label = Label(membership_info, bg="powder blue", text="Date Over Due:", font=("arial", 12, "bold"),
                                  padx=6,
                                  pady=6)
dateOverDue_label.grid(row=7, column=2, sticky=W)
dateOverDue_txt = Entry(membership_info, font=("arial", 12, "bold"), textvariable=dateoverdue_db, width=29)
dateOverDue_txt.grid(row=7, column=3)

actualPrice_label = Label(membership_info, bg="powder blue", text="Actual Price:", font=("arial", 12, "bold"),
                                  padx=6,
                                  pady=6)
actualPrice_label.grid(row=8, column=2, sticky=W)
actualPrice_txt = Entry(membership_info, font=("arial", 12, "bold"), textvariable=finalprice_db, width=29)
actualPrice_txt.grid(row=8, column=3)


# ----Font Right Info Frame
book_details = LabelFrame(frame, text="Book Details", padx=5, bg="powder blue", fg='blue', bd=8,
                                  font=("times new roman", 14, "bold"))
book_details.place(x=870, y=0, width=585, height=365)

# ------Book Name
list_scrollber = Scrollbar(book_details)
list_scrollber.grid(row=0, column=1, sticky="ns")

#_______Define all Book Name
listBOOK = ['C Programming Absolute Beginners Guide', 'The C Programming Language',
                    'Learn C the Hard Way','C++ Primer', 'Effective Modern C++',
                    'The C++ Programming Language', 'Python Crash Course',
                    'Automate the Boring Stuff With Python', 'Learning Python',
                    'The Hundred-Page Machine Learning Book','Machine Learning For Hackers',
                    'Machine Learning', 'Head First Statistics', 'Practical Statistics For Data Scientists',
                    'Introduction to Probability',
                    'The Man Who Counted','Zero', 'The Triumph of Numbers', 'Probabilistic Robotics',
                    'Robotics Modelling, Planning and Control','Planning Algorithms']



#--------Showing all books name as a list
listBox = Listbox(book_details, font=("arial", 10, "bold"), width=30, height=19)
listBox.bind('<<ListboxSelect>>', lambda z: selectBook()) #bine the listbox
listBox.grid(row=0, column=0, padx=5)
list_scrollber.config(command=listBox.yview)
for item in listBOOK:
        listBox.insert(END, item)

# ------Show Description
txtBox = Text(book_details, font=("arial", 10, "bold"), width=42, height=19, padx=2, pady=6)
txtBox.grid(row=0, column=2, padx=10)

# --Buttons Frame
button_frame = Frame(screen, bd=10, relief=RIDGE, padx=220, bg="powder blue")
button_frame.place(x=0, y=513, width=1550, height=60)

# ------Buttons
add_pic = PhotoImage(file="add.png")
add_button = Button(button_frame, command=add_data, image=add_pic, bd=0, bg="powder blue")
add_button.grid(row=0, column=0)

show_pic = PhotoImage(file="show.png")
show_button = Button(button_frame, command=showing_data_in_textbox, image=show_pic, bd=0, bg="powder blue")
show_button.grid(row=0, column=1)

update_pic = PhotoImage(file="update.png")
update_button = Button(button_frame, command=update_btn, image=update_pic, bd=0, bg="powder blue")
update_button.grid(row=0, column=2)

delete_pic = PhotoImage(file="delete.png")
delete_button = Button(button_frame, command=delete, image=delete_pic, bd=0, bg="powder blue")
delete_button.grid(row=0, column=3)

reset_pic = PhotoImage(file="reset.png")
reset_button = Button(button_frame, command=reset, image=reset_pic, bd=0, bg="powder blue")
reset_button.grid(row=0, column=4)

exit_pic = PhotoImage(file="exit.png")
exit_button = Button(button_frame, command=exit_btn, image=exit_pic, bd=0, bg="powder blue")
exit_button.grid(row=0, column=5)



# --All Info Frame
all_info_frame = Frame(screen, bd=10, relief=RIDGE, padx=20, bg="powder blue")
all_info_frame.place(x=0, y=571, width=1550, height=229)

table_frame = Frame(all_info_frame, bd=6, relief=RIDGE, bg="powder blue")
table_frame.place(x=0, y=5, width=1490, height=200)

table_x_scroll = ttk.Scrollbar(table_frame, orient=HORIZONTAL)
table_y_scroll = ttk.Scrollbar(table_frame, orient=VERTICAL)

library_table = ttk.Treeview(table_frame, columns=("membertype", "prnno", "memberid",
                                                           "firstname", "lastname", "address1",
                                                           "address2", "postid", "mobile", "bookid",
                                                           "booktitle", "auther", "dateborrowed",
                                                           "datedue", "days", "latereturnfine",
                                                           "dateoverdue", "finalprice"),
                                     xscrollcommand=table_x_scroll.set, yscrollcommand=table_y_scroll.set)
table_x_scroll.pack(side=BOTTOM, fill=X)
table_y_scroll.pack(side=RIGHT, fill=Y)
table_x_scroll.config(command=library_table.xview)
table_y_scroll.config(command=library_table.yview)

library_table.heading("membertype", text="Member Type")
library_table.heading("prnno", text="PRN No.")
library_table.heading("memberid", text="ID")
library_table.heading("firstname", text="First Name")
library_table.heading("lastname", text="Surname")
library_table.heading("address1", text="Address1")
library_table.heading("address2", text="Address2")
library_table.heading("postid", text="Post ID")
library_table.heading("mobile", text="Mobile")
library_table.heading("bookid", text="Book ID")
library_table.heading("booktitle", text="Book Title")
library_table.heading("auther", text="Auther")
library_table.heading("dateborrowed", text="Date Borrowed")
library_table.heading("datedue", text="Date Due")
library_table.heading("days", text="Days On Book")
library_table.heading("latereturnfine", text="Late Return Fine")
library_table.heading("dateoverdue", text="Date Over Due")
library_table.heading("finalprice", text="Final Price")

library_table["show"] = "headings"
library_table.pack(fill=BOTH, expand=1)

library_table.column("membertype", width=130)
library_table.column("prnno", width=130)
library_table.column("memberid", width=130)
library_table.column("firstname", width=150)
library_table.column("lastname", width=150)
library_table.column("address1", width=150)
library_table.column("address2", width=150)
library_table.column("postid", width=80)
library_table.column("mobile", width=130)
library_table.column("bookid", width=130)
library_table.column("booktitle", width=150)
library_table.column("auther", width=150)
library_table.column("dateborrowed", width=80)
library_table.column("datedue", width=80)
library_table.column("days", width=80)
library_table.column("latereturnfine", width=80)
library_table.column("dateoverdue", width=80)
library_table.column("finalprice", width=80)


#--------Showing Database
fatch_data()
library_table.bind("<ButtonRelease-1>", lambda r: get_member_info()) #Bind the table





#__Call Main Screen And Showing Main Screen Again And Again
screen.mainloop()
